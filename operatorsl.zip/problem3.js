// You have to take five numbers, stored in variables with the following namesone,
// two, three, four, five, six
let one = 1;
let two = 2;
let three= 3;
let four = 4;
let five = 5;
let six = 6;
let sum1= (two+five+six)*2
let sum2= (three+four)*3;
console.log(one+sum1+sum2)