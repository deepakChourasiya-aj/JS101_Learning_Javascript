// You have to take five numbers, stored in the variables with the following names
let one = 1*2;

let two = 2*2;

let three = 3*2;

let four = 4*2 ;

let five = 5*2 ;
console.log(one+two+three+four+five);
